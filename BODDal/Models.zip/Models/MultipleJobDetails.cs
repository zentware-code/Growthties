﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BODDal.Models
{
    public class MultipleJobDetails
    {
        public string MJD_Title { get; set; }
		public string MJD_StartDate { get; set; }
        public string MJD_EndDate { get; set; }
    }
}
