﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BODDal.Models
{
    public class DashBoard
    {
        public int? RegisDoctor { get; set; }
        public int? TodayPatient { get; set; }
        public decimal? TodayCollec { get; set; }
        public int? TodayAssgnDoc { get; set; }
        public int? MonthPatient { get; set; }
        public int? MonthAssgnDoc { get; set; }
    }
}
