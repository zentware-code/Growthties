﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BODDal.Models
{
    public class ProjectDetails
    {
        public int? PD_Id { get; set; }
        public string PD_ProjectName { get; set; }
        public string PD_DurationFromDate { get; set; }
        public string PD_DurationToDate { get; set; }
        public string PD_Description { get; set; }
        public int? PD_EnterpriseId { get; set; }
        public decimal? PD_Budget { get; set; }
        public int? PD_CreatedBy { get; set; }
        public bool? IsCompleted { get; set; }
    }


}
