﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BODDal.Models
{
  public  class EnterpriiseWiseSMME
    {
        public int? EWS_EnterpriseId { get; set; }
        public int? EWS_SMME_Id { get; set; }
        public string Transactiontype { get; set; }

        public string ENR_CompanyName { get; set; }
        public string ENR_PrimaryContactEmail { get; set; }
        public string ENR_PrimaryContactNo { get; set; }
        public string ENR_CreatedDate { get; set; }
        public string ENR_Logo { get; set; }
        public string ENR_Prefix { get; set; }

        public string SMME_CompanyName { get; set; }
        public string SMME_Logo { get; set; }
        public string SMME_Prefix { get; set; }
        public string SMME_PrimaryContactEmail { get; set; }
        public string SMME_PrimaryContactNo { get; set; }
        public int? TotalProject { get; set; }
        public int? TotalJob { get; set; }
        public List<EnterpriiseWiseSMME> EnterpriiseWiseSMMEList { get; set; }
        public EnterpriiseWiseSMME()
        {
            EnterpriiseWiseSMMEList = new List<EnterpriiseWiseSMME>();
        }
        
    }
}
