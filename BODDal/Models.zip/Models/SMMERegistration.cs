﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BODDal.Models
{
   public class SMMERegistration
    {
        public Int64? SMME_Id { get; set; }
        public string SMME_CompanyName { get ; set ; }
        public string SMME_RegNumber { get ; set ; }
        public int? SMME_SectorId { get ; set ; }
        public int? SMME_SMMETypeId { get ; set ; }
        public int? SMME_ProvinceId { get ; set ; }
        public string SMME_BusinessAddress { get ; set ; }
        public int? SMME_LegalEntityTypeId { get ; set ; }
        public string SMME_TaxNumber { get ; set ; }
        public string SMME_VatNumber { get ; set ; }
        public string SMME_IncorporationDate { get ; set ; }
        public string SMME_RegNum2 { get ; set ; }
        public string SMME_PrimaryContactName { get ; set ; }
        public string SMME_PrimaryContactEmail { get ; set ; }
        public string SMME_Password { get; set; }
        public string SMME_SecondaryContactName { get ; set ; }
        public string SMME_SecondaryContactEmail { get ; set ; }
        public string SMME_PrimaryContactNo { get; set; }
        public string SMME_SecondaryContactNo { get; set; }
        public string SMME_BillingContactNumber { get ; set ; }
        public string SMME_BillingAddress { get ; set ; }
        public string SMME_BusinessDes { get ; set ; }
        public string SMME_WebsiteURL { get ; set ; }
        public string SMME_ProfilePic { get; set; }
        public string SMME_SocialMediaLink { get ; set ; }
        public string SMME_Logo { get; set; }
        public string SMME_Prefix { get; set; }
        public string SMME_Active { get; set; }
        public string SMME_class { get; set; }
        public string Mode { get; set; }
        public int? UserId { get; set; }
        public string Ischecked { get; set; }
        public int? chkvalue { get; set; }
        public int?  SMME_EnterpriseId { get; set; }

        public List<CustomerDetails> CustomerDetailsList { get; set; }
        public SMMERegistration()
        {
            CustomerDetailsList = new List<CustomerDetails>();
        }
    }
}
