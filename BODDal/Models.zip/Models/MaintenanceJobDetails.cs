﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BODDal.Models
{
    public class MaintenanceJobDetails
    {
        public string MNJD_Frequency { get; set; }
        public int? MNJD_VisitCount { get; set; }
        public string MNJD_Date { get; set; }
    }
}
